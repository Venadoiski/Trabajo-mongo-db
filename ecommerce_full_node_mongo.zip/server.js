const express=require("express");
const mongoose=require("mongoose");
const cors=require("cors");

const productosRoutes=require("./routes/productos");
const clientesRoutes=require("./routes/clientes");
const pedidosRoutes=require("./routes/pedidos");

const app=express();
app.use(express.json());
app.use(cors());

mongoose.connect("mongodb://localhost:27017/EcommerceDB")
.then(()=>console.log("MongoDB conectado"))
.catch(err=>console.log(err));

app.use("/api/productos", productosRoutes);
app.use("/api/clientes", clientesRoutes);
app.use("/api/pedidos", pedidosRoutes);

app.listen(3000,()=>console.log("Servidor en puerto 3000"));
