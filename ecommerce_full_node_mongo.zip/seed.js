const mongoose=require("mongoose");
const Producto=require("./models/Producto");
const Cliente=require("./models/Cliente");
const Pedido=require("./models/Pedido");

mongoose.connect("mongodb://localhost:27017/EcommerceDB");

async function run(){
  await Producto.deleteMany();
  await Cliente.deleteMany();
  await Pedido.deleteMany();

  const productos=await Producto.insertMany([
    {nombre:"Mouse Gamer",precio:50,stock:10,activo:true,etiquetas:["gamer"]},
    {nombre:"Teclado",precio:120,stock:0,activo:false,etiquetas:["pc"]}
  ]);

  const clientes=await Cliente.insertMany([
    {nombre:"Juan",email:"juan@mail.com",registro_fecha:new Date("2023-01-01"),preferencias:["electronica"]},
    {nombre:"Ana",email:"ana@mail.com",registro_fecha:new Date(),preferencias:["hogar"]}
  ]);

  await Pedido.insertMany([
    {cliente_id:clientes[0]._id,fecha_pedido:new Date(),estado:"Pendiente",total:50,items:[
      {producto_id:productos[0]._id,cantidad:1,subtotal:50}
    ]}
  ]);

  console.log("Seed completado");
  process.exit();
}
run();
