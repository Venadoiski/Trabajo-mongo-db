const mongoose=require("mongoose");

const pedidoSchema=new mongoose.Schema({
  cliente_id:mongoose.Schema.Types.ObjectId,
  fecha_pedido:Date,
  estado:String,
  total:Number,
  items:[
    {producto_id:mongoose.Schema.Types.ObjectId,cantidad:Number,subtotal:Number}
  ]
});
module.exports=mongoose.model("Pedido",pedidoSchema);
