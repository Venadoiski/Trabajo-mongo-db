const mongoose=require("mongoose");

const clienteSchema=new mongoose.Schema({
  nombre:String,
  email:String,
  registro_fecha:Date,
  preferencias:[String]
});
module.exports=mongoose.model("Cliente",clienteSchema);
