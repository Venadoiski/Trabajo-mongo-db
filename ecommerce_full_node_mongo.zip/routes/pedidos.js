const express=require("express");
const router=express.Router();
const Pedido=require("../models/Pedido");

router.get("/", async(req,res)=>res.json(await Pedido.find()));
router.post("/", async(req,res)=>res.json(await Pedido.create(req.body)));

module.exports=router;
