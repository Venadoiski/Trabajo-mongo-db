const express=require("express");
const router=express.Router();
const Producto=require("../models/Producto");

router.get("/", async(req,res)=>res.json(await Producto.find()));
router.post("/", async(req,res)=>res.json(await Producto.create(req.body)));
router.put("/:id", async(req,res)=>res.json(await Producto.findByIdAndUpdate(req.params.id,req.body,{new:true})));
router.delete("/:id", async(req,res)=>res.json(await Producto.findByIdAndDelete(req.params.id)));

module.exports=router;
